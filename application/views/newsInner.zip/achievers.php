    <div class="subheader" style="background:linear-gradient(to right,rgba(0,0,0,0.85) 40%,rgba(0,0,0,0.3)), url('<?=base_url()?>assets/images/header-achievers.jpg') no-repeat">
        <div class="wrapper">
            <h2 class="subheader-head serif wow fadeInUp" data-wow-delay="1s">Achievers</h2>
            <!-- <p class="subheader-txt wow fadeInUp" data-wow-delay="1.2s">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ullam, ut facere! Perferendis voluptatibus praesentium veritatis facere culpa neque alias autem.</p> -->
        </div>
    </div>

    <section class="all-ach wow fadeInUp" data-wow-delay="2s">
        <div class="wrapper">
            <img class='lazyload' data-src="<?=base_url('assets/images/')?>all-achievers.jpg" alt="GGEA achievers">
        </div>
    </section>